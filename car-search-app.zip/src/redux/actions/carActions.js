// src/redux/actions/carActions.js
export const setCars = (cars) => ({
  type: "SET_CARS",
  payload: cars
});

export const setSearchTerm = (term) => ({
  type: "SET_SEARCH_TERM",
  payload: term
});

export const setCurrentPage = (page) => ({
  type: "SET_CURRENT_PAGE",
  payload: page
});
