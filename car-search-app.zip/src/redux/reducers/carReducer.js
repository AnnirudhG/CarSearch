// src/redux/reducers/carReducer.js
const initialState = {
  cars: [],
  searchTerm: "",
  currentPage: 1
};

const carReducer = (state = initialState, action) => {
  switch (action.type) {
    case "SET_CARS":
      return {
        ...state,
        cars: action.payload
      };
    case "SET_SEARCH_TERM":
      return {
        ...state,
        searchTerm: action.payload
      };
    case "SET_CURRENT_PAGE":
      return {
        ...state,
        currentPage: action.payload
      };
    default:
      return state;
  }
};

export default carReducer;
