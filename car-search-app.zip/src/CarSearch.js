import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useParams, Link } from "react-router-dom";
import {
  setCars,
  setSearchTerm,
  setCurrentPage
} from "./redux/actions/carActions";
import CarCard from "./CarCard";
import Pagination from "./Pagination";
import carData from "./data/cars.json"; // Import the JSON data

function CarSearch() {
  const { page } = useParams();
  const dispatch = useDispatch();
  const { cars, searchTerm, currentPage } = useSelector((state) => state.car);

  // Calculate the total number of pages based on filtered cars and items per page
  const itemsPerPage = 6;
  const totalCars = cars.filter((car) =>
    car.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const pageCount = Math.ceil(totalCars.length / itemsPerPage);

  useEffect(() => {
    // Simulated data fetching (replace with actual data from JSON file)
    // Here, we set the cars in Redux state using the imported JSON data
    dispatch(setCars(carData));
  }, [dispatch]);

  // Handle changing the current page
  useEffect(() => {
    // Ensure the current page is a valid number
    const newPage = parseInt(page, 10) || 1;

    // Update the current page in Redux state
    dispatch(setCurrentPage(newPage));
  }, [page, dispatch]);

  // Slice the cars to display on the current page
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentCars = totalCars.slice(startIndex, endIndex);

  return (
    <div>
      <h1>Car Search</h1>
      <center>
        {" "}
        <input
          type="text"
          placeholder="Search for cars"
          value={searchTerm}
          onChange={(e) => dispatch(setSearchTerm(e.target.value))}
        />
      </center>

      <div className="car-grid">
        {currentCars.map((car) => (
          <CarCard key={car.id} car={car} />
        ))}
      </div>

      <Pagination currentPage={currentPage} pageCount={pageCount} />
    </div>
  );
}

export default CarSearch;
