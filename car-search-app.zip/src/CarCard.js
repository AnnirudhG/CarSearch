import React from "react";

function CarCard({ car }) {
  return (
    <div className="car-card">
      <img src={car.image} alt={car.name} />
      <h2>{car.name}</h2>
      <p>Year: {car.year}</p>
      <p>Number of Seats: {car.seats}</p>
      <p>Fuel Type: {car.fuelType}</p>
      <p>Mileage: {car.mileage}</p>
      <p>Transmission: {car.transmission}</p>
      <p>Price: {car.price}</p>
    </div>
  );
}

export default CarCard;
