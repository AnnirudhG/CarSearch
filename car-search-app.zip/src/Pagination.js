import React from "react";
import { Link } from "react-router-dom";

function Pagination({ currentPage, pageCount }) {
  const generatePageLinks = () => {
    const links = [];

    for (let i = 1; i <= pageCount; i++) {
      links.push(
        <Link
          to={`/page/${i}`}
          key={i}
          className={i === currentPage ? "active" : ""}
        >
          {i}
        </Link>
      );
    }

    return links;
  };

  return <div className="pagination">{generatePageLinks()}</div>;
}

export default Pagination;
